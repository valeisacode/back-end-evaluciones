
from django.shortcuts import render

def inicio(request):
    # Reemplaza 'index.html' por el nombre exacto del archivo que creaste dentro de tareas/templates/
    return render(request, 'index.html')

