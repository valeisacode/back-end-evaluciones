from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("tareas.urls")),
]

handler404 = "tareas.views.error_404"
