from django.shortcuts import render

def inicio(request):
    contexto = {
        "nombre_proyecto": "Sistema de Control de Tareas",
        "descripcion": "Aplicación inicial para organizar, visualizar y gestionar tareas pendientes.",
        "estado": "Proyecto Django operativo",
    }
    return render(request, "tareas/inicio.html", contexto)

def error_404(request, exception):
    return render(request, "404.html", status=404)
